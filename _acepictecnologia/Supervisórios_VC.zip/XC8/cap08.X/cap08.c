#include "../bibliotecas/config.h"
#include "../bibliotecas/eusart.h"

#include <xc.h>


#define _XTAL_FREQ 8000000  //Define a frequ�ncia de clock utilizada

int i = 0;              //Vari�vel de controle para dados recebidos pela serial
char recUSART[3];       //matriz de armazenamento de mensagem recevida pela serial

void __interrupt() isr(void) {
    
    char x;
    
    x = RCREG;              //Dado recebido e armazenado em x
    
    if (x == 0x0D)          //Se dado = /r (carriage return)
    {
        i = 0;				//Zera a vari�vel i
        
        /*Verifica se o dado enviado foi LL1
		  se foi, atribui n�vel l�gico 1 ao pino RD0 (acende LED) */
		if (recUSART[0] == 'L' && recUSART[1] == 'L' && recUSART[2] == '1')
            PORTDbits.RD0 = 1;
        
        /*Verifica se o dado enviado foi DL1
		  se foi, atribui n�vel l�gico 0 ao pino RD0 (apaga LED) */
		if (recUSART[0] == 'D' && recUSART[1] == 'L' && recUSART[2] == '1')
            PORTDbits.RD0 = 0;
        
    } else 
    {
        recUSART[i] = x;    //Armazena o dado recebido em um �ndice de recUSART
        i++;                //Incrementa a vari�vel i
    }
    
    PIR1bits.RCIF = 0;      //Limpa o flag de interrup��o pela recep��o na serial    
    
}

void main(void) {
    
    // ** Interrup��o pela recep��o de dados na serial **
    INTCONbits.GIE=1;       //Habilita Interrup��o Global
    INTCONbits.PEIE=1;      //Habilita Interrup��o de Perif�ricos
    PIR1bits.RCIF=0;        //Limpa o Flag de Interrup��o por rece��o na serial
    PIE1bits.RCIE=1;        //Habilita interrup��o por recep��o na serial
    
    TRISDbits.TRISD0 = 0;   //Direciona o pino 0 da porta D como sa�da
    PORTDbits.RD0 = 0;      //Atribui n�vel l�gico 0 ao pino RD0 (Led apagado))
    
    init_EUSART();          //Inicia USART
    
    while(1); 				//Loop principal
}
