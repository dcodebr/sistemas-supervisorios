#include <xc.h>

//Prot�tipos para as fun��es transmiss�o e recep��o serial
void init_EUSART(void);
void escreve_EUSART(char c);
void string_EUSART(const char *c);

