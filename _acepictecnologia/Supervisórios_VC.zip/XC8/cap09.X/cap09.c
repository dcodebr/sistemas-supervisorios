#include "../bibliotecas/config.h"
#include "../bibliotecas/eusart.h"

#include <xc.h>
#include <stdio.h>          //Biblioteca que contem defini��o de sprintf

#define _XTAL_FREQ 8000000  //Define a frequ�ncia de clock utilizada

char adc = 0;           //Vari�vel de controle para in�cio e finaliza��o
                        //de envio de dados pela serial
unsigned long res_ad;	//vari�vel de armazenamento da convers�o AD
int i = 0;              //Vari�vel de controle para dados recebidos pela serial
char bufUSART[50];		//matriz de armazenamento da mensagem para a Serial
char recUSART[3];       //matriz de armazenamento de mensagem recevida pela serial

void __interrupt() isr(void) {
    
    char x;
    
    x = RCREG;              //Dado recebido e armazenado em x
    
    if (x == 0x0D)          //Se dado = /r (carriage return)
    {
        i = 0;
        
        /*Verifica se o dado enviado foi IN
		  se foi, atribui n�vel l�gico 1 � vari�vel adc
		  para envio da leitura anal�gica/digital ao aplicativo*/
		if (recUSART[0] == 'I' && recUSART[1] == 'N')
            adc = 1;
        
        /*Verifica se o dado enviado foi FN
		  se foi, atribui n�vel l�gico 0 � vari�vel adc
		  para finalizar o envio da leitura anal�gica/digital
		  ao aplicativo*/
		if (recUSART[0] == 'F' && recUSART[1] == 'N')
            adc = 0;
        
    } else 
    {
        recUSART[i] = x;    //Armazena o dado recebido em um �ndice de recUSART
        i++;                //Incrementa a vari�vel i
    }
    
    PIR1bits.RCIF = 0;      //Limpa o flag de interrup��o pela recep��o na serial    
    
}

void main(void) {
    
    // ** Interrup��o pela recep��o de dados na serial **
    INTCONbits.GIE=1;       //Habilita Interrup��o Global
    INTCONbits.PEIE=1;      //Habilita Interrup��o de Perif�ricos
    PIR1bits.RCIF=0;        //Limpa o Flag de Interrup��o por rece��o na serial
    PIE1bits.RCIE=1;        //Habilita interrup��o por recep��o na serial
    
    init_EUSART();          //Inicia USART
    
    ADCON2 = 0b10100001;    /*ADFM1 = 1 -> Resultado da convers�o AD
                                    ... justificado � direita
                            -
                            ****Velocidade de aquisi��o em 8TAD
                            ACQT2 = 1
                            ACQT1 = 0
                            ACQT0 = 0
                            ****Fonte de clock em Fosc/8
                            ADCS2 = 0
                            ADCS1 = 0
                            ADCS0 = 1*/        
 
    ADCON1 = 0b00001101;    /* -
                            -
                            VCFG1 = 0 -> Vref- = terra
                            VCFG0 = 1 -> Vref+ = VDD
                            *****Seleciona os canais AN0 e AN1 como anal�gicos
                            PCFG3 = 1
                            PCFG2 = 1
                            PCFG1 = 0
                            PCFG0 = 1*/
    
    __delay_ms(500);		//Gera atraso de 500ms
    
    while(1) {
        if (adc)
        {
            ADCON0 = 0b00000001;  		/*Seleciona Canal 0 para convers�o
                                      ...e habilita o conversor AD*/
            ADCON0bits.GO = 1;          //Inicializa a convers�o
            while(ADCON0bits.GO);       //Aguarda o t�rmino da convers�o
        
            __delay_us(100);            //Gera atraso de 100us
 
            res_ad = ADRES;             //atribui o valor convertido � vari�vel res_ad
            
            //Prepara envio dos dados para serial
			sprintf(bufUSART,"AN0=%04lu", res_ad);
        
            //Envia os dados para a serial
			string_EUSART(bufUSART);
            
            __delay_ms(500);			//Gera atraso de 500ms            
        }
    }
}
