/**************************************************************************************

  Interfacing DHT22 (AM2302 - RHT03) sensor with PIC16F887 microcontroller.
  C Code for mikroC PRO for PIC compiler
  Internal oscillator used @ 8MHz
  Configuration words: CONFIG1 = 0x2CD4
                       CONFIG2 = 0x0700
  This is a free software with NO WARRANTY.
  https://simple-circuit.com/

***************************************************************************************/


// LCD module connections
sbit LCD_RS at RE0_bit;
sbit LCD_EN at RE1_bit;
sbit LCD_D4 at RD4_bit;
sbit LCD_D5 at RD5_bit;
sbit LCD_D6 at RD6_bit;
sbit LCD_D7 at RD7_bit;
sbit LCD_RS_Direction at TRISE0_bit;
sbit LCD_EN_Direction at TRISE1_bit;
sbit LCD_D4_Direction at TRISD4_bit;
sbit LCD_D5_Direction at TRISD5_bit;
sbit LCD_D6_Direction at TRISD6_bit;
sbit LCD_D7_Direction at TRISD7_bit;
// end LCD module connections

// DHT22 sensor connection (here sensor data pin is connected to pin RB0)
sbit DHT22_PIN at RB0_bit;
sbit DHT22_PIN_Direction at TRISB0_bit;
// End DHT11 sensor connection

char temperature[] = "Temp = 00.0 C  ";
char humidity[] = "RH   = 00.0 %  ";
unsigned short T_byte1, T_byte2, RH_byte1, RH_byte2, CheckSum ;
unsigned int Temp, RH;

void Start_Signal(void) {
  DHT22_PIN_Direction = 0;                    // Configure connection pin as output
  DHT22_PIN = 0;                              // Connection pin output low
  delay_ms(25);                               // Wait 25 ms
  DHT22_PIN = 1;                              // Connection pin output high
  delay_us(25);                               // Wait 25 us
  DHT22_PIN_Direction = 1;                    // Configure connection pin as input
}

unsigned short Check_Response() {
  TMR1H = 0;                                  // Reset Timer1
  TMR1L = 0;
  TMR1ON_bit = 1;                             // Enable Timer1 module
  while(!DHT22_PIN && TMR1L < 100);           // Wait until DHT11_PIN becomes high (checking of 80�s low time response)
  if(TMR1L > 99)                              // If response time > 99�S  ==> Response error
    return 0;                                 // Return 0 (Device has a problem with response)
  else {    TMR1H = 0;                        // Reset Timer1
    TMR1L = 0;
    while(DHT22_PIN && TMR1L < 100);          // Wait until DHT11_PIN becomes low (checking of 80�s high time response)
    if(TMR1L > 99)                            // If response time > 99�S  ==> Response error
      return 0;                               // Return 0 (Device has a problem with response)
    else
      return 1;                               // Return 1 (response OK)
  }
}

unsigned short Read_Data(unsigned short* dht_data) {
  short i;
  *dht_data = 0;
  for(i = 0; i < 8; i++){
    TMR1H = 0;                                // Reset Timer1
    TMR1L = 0;
    while(!DHT22_PIN)                         // Wait until DHT11_PIN becomes high
      if(TMR1L > 100) {                       // If low time > 100  ==>  Time out error (Normally it takes 50�s)
        return 1;
      }
    TMR1H = 0;                                // Reset Timer1
    TMR1L = 0;
    while(DHT22_PIN)                          // Wait until DHT11_PIN becomes low
      if(TMR1L > 100) {                       // If high time > 100  ==>  Time out error (Normally it takes 26-28�s for 0 and 70�s for 1)
        return 1;                             // Return 1 (timeout error)
      }
     if(TMR1L > 50)                           // If high time > 50  ==>  Sensor sent 1
       *dht_data |= (1 << (7 - i));           // Set bit (7 - i)
  }
  return 0;                                   // Return 0 (data read OK)
}

void main() {
  //OSCCON =  0X70;                  // Set internal oscillator to 8 MHz
  //ANSELH = 0;                      // Configure all PORTB pins as digital
  ADCON1 = 0xFF;
  T1CON = 0x10;                    // Set Timer1 clock source to internal with 1:2 prescaler (Timer1 clock = 1 MHz)
  TMR1H = 0;                       // Reset Timer1
  TMR1L = 0;
  Lcd_Init();                      // Initialize LCD module
  Lcd_Cmd(_LCD_CURSOR_OFF);        // cursor off
  Lcd_Cmd(_LCD_CLEAR);             // clear LCD
  lcd_out(1, 5, "Teste!");
  while(1) {

    Start_Signal();                // Send start signal to the sensor

    if(Check_Response()) {         // Check if there is a response from sensor (If OK start reading humidity and temperature data)
    // Read (and save) data from the DHT11 sensor and check time out errors
      if(Read_Data(&RH_byte1) || Read_Data(&RH_byte2) || Read_Data(&T_byte1) || Read_Data(&T_byte2) || Read_Data(&Checksum)) {
        Lcd_Cmd(_LCD_CLEAR);                               // clear LCD
        lcd_out(1, 5, "Time out!");                        // Display "Time out!"
      }
      else {                                               // If there is no time out error
        if(CheckSum == ((RH_Byte1 + RH_Byte2 + T_Byte1 + T_Byte2) & 0xFF)) {
        // If there is no checksum error
          RH = RH_byte1;
          RH = (RH << 8) | RH_byte2;
          Temp = T_byte1;
          Temp = (Temp << 8) | T_byte2;
          if (Temp > 0X8000){
            temperature[6] = '-';
            Temp = Temp & 0X7FFF;
          }
          else
            temperature[6] = ' ';
          temperature[7]  = (Temp / 100) % 10  + 48;
          temperature[8]  = (Temp / 10) % 10  + 48;
          temperature[10] = Temp % 10  + 48;
          if(RH == 1000)                              // If the relative humidity = 100.0 %
            humidity[6]  = 1 + 48;                    // Put 1 of hundreds
          else
            humidity[6]  = ' ';                       // Put space ' '
          humidity[7]  = (RH / 100) % 10 + 48;
          humidity[8]  = (RH / 10) % 10 + 48;
          humidity[10] = RH % 10 + 48;
          temperature[11] = 223;                      // Put degree symbol (�)
          lcd_out(1, 1, temperature);
          lcd_out(2, 1, humidity);
        }
        // If there is a checksum error
        else {
          Lcd_Cmd(_LCD_CLEAR);                        // clear LCD
          lcd_out(1, 1, "Checksum Error!");
        }
      }
    }
    // If there is a response (from the sensor) problem
    else {
      Lcd_Cmd(_LCD_CLEAR);                 // clear LCD
      lcd_out(1, 3, "No response");
      lcd_out(2, 1, "from the sensor");
    }

    TMR1ON_bit = 0;                        // Disable Timer1 module
    delay_ms(1000);                        // Wait 1 second

  }
}
// End of code