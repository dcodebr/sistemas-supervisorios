// DHT22 sensor connection (here data pin is connected to RB0)
sbit DHT22_PIN at RB0_bit;
sbit DHT22_PIN_Dir at TRISB0_bit;

// variables declaration
unsigned short T_byte1, T_byte2, RH_byte1, RH_byte2, CheckSum;
unsigned int rh = 0, temp = 0, rl1 = 0, rl2 = 0;

/*vari�veis de controle de tempo em 2 segundos para
  leitura do sensor DHT22 */
unsigned short conta = 0, tmp = 0;

unsigned short i = 0;   //Vari�vel de controle para dados recebidos pela serial
char bufUSART[18]; // = "TMP:000:UMD:000:00";                //matriz de armazenamento da mensagem para a Serial
char recUSART[5];       //matriz de armazenamento de mensagem recevida pela serial

char txt[7];

void interrupt(void)
{
    if (TMR0IF_bit)                     //Se ocorreu a interrup��o do Timer 0
    {
        conta++;                        //Incrementa a vari�vel conta
        if (conta >= 80)         //25ms cada interrup��o * 80 = 2000ms
        {
            conta = 0;                //Zera a vari�vel conta
            tmp = 1;                //Atribui 1 � vari�vel tmp
        }
        TMR0L = 61;                        //Retorna o valor inicial ao registrado TIMER0
        TMR0IF_bit = 0;                        //Limpa o flag de interrup��o do TIMER0
    }

    if (RCIF_bit)                       //Se ocorreu a interrup��o pela recep��o na serial
    {
    if (RCREG == 0x0D)      //Se dado = '/r' (carriage return)
    {
        i = 0;                                //Zera a vari�vel i

        //Verifica se o dado recebido � igual a LG1 ou LG2
       if (recUSART[0] == 'L' && recUSART[1] == 'G')
        {
            /*Sendo LG1, atribui 1 ao pino 3 da porta A
              e o valor 1 � vari�vel rl1 - indicando que o
                          circuito do Rel� 1 est� acionado*/
                        if (recUSART[2] == '1')
            {
                rl1 = 1;
                PORTA.F3 = 1;
            }

                        /*Sendo LG2, atribui 1 ao pino 5 da porta A
              e o valor 1 � vari�vel rl2 - indicando que o
                          circuito do Rel� 2 est� acionado*/
            if (recUSART[2] == '2')
            {
                rl2 = 1;
                PORTA.F5 = 1;
            }
        }

        //Verifica se o dado recebido � igual a DG1 ou DG2
                if (recUSART[0] == 'D' && recUSART[1] == 'G')
        {
            /*Sendo DG1, atribui 0 ao pino 3 da porta A
              e o valor 0 � vari�vel rl1 - indicando que o
                          circuito do Rel� 1 est� desligado*/
            if (recUSART[2] == '1')
            {
                rl1 = 0;
                PORTA.F3 = 0;
            }

            /*Sendo DG1, atribui 0 ao pino 5 da porta A
              e o valor 0 � vari�vel rl2 - indicando que o
                          circuito do Rel� 2 est� desligado*/
            if (recUSART[2] == '2')
            {
                rl2 = 0;
                PORTA.F5 = 0;
            }
        }

    }
    else                        //Se RCREG != 0x0D
    {
        recUSART[i] = RCREG;    //Armazena o dado recebido em um �ndice de recUSART
        i++;                    //Incrementa a vari�vel i
    }

    RCIF_bit = 0;      //Limpa o flag de interrup��o pela recep��o na serial
    }
}

// send start signal to the sensor
void start_signal(void) {
    DHT22_PIN_Dir = 0;  //Direciona o pino 0 da porta B como sa�da

    DHT22_PIN = 0;      //Atribui n�vel l�gico 0 ao pino 0 da porta B
    delay_ms(18);       //Atraso de 18ms

    DHT22_PIN = 1;      //Atribui n�vel l�gico 1 ao pino 0 da porta B
    delay_us(30);     //Atraso de 30us

    DHT22_PIN_Dir = 1;  /*Direciona o pino 0 da porta B como entrada
                          para leitura dos dados do sensor */
}

// Check sensor response
unsigned short check_response() {
  TMR1H = 0;                        //Inicia o TIMER1 em 0
  TMR1L = 0;
  TMR1ON_bit = 1;                       //Habilita m�dulo TIMER1
  while(!DHT22_PIN && TMR1L < 100); /*Aguarda at� que o pino de sinal do DHT22
                                      se torne n�vel alto (1) - Verifica tamb�m
                                      se houve a resposta em menos de
                                      aproximadamente 80us */
  if(TMR1L > 99)                    /*Se o Contador do TIMER1 ultrapassar 99
                                      +/- 99us ==> Houve erro na leitura */
    return 0;                       //Retorna 0 (problema na resposta do sensor)

  else                              //Caso o tempo seja menor que 99us
  {
    TMR1H = 0;                      //Reinicia o TIMER1 em 0
    TMR1L = 0;
    while(DHT22_PIN && TMR1L < 100); /*Aguarda at� que o pino de sinal do DHT22
                                      se torne n�vel baixo (0) - Verifica tamb�m
                                      se houve a resposta em menos de
                                      aproximadamente 80us */
    if(TMR1L > 99)                  /*Se o Contador do TIMER1 ultrapassar 99
                                      +/- 99us ==> Houve erro na leitura */
      return 0;                     //Retorna 0 (problema na resposta do sensor)
    else
      return 1;                     //Retorna 1 (resposta OK)
  }
}

// Data read function
unsigned short read_byte()
{
  unsigned short num = 0, j;

    DHT22_PIN_Dir = 1;      /*Direciona o pino 0 da porta B como entrada
                              para leitura dos dados do sensor */

    for (j = 0; j < 8; j++)
    {
        while(!DHT22_PIN);  //Aguarda que pino de sinal do sensor seja 1
        TMR1H = 0;          //Inicia o TIMER1 em 0
        TMR1L = 0;
        TMR1ON_bit = 1;         //Habilita m�dulo TIMER1

        while(DHT22_PIN);   //Aguarda que pino de sinal do sensor seja 0
        TMR1ON_bit = 0;         //Desabilita m�dulo TIMER1

        if(TMR1L > 40)           //Se TMR1L > 40  ==>  Sensor enviou 1
            num |= 1 << (7 - j); //Ajusta o bit referente (7 - j)
    }
  return num;               //Retorna o valor lido
}

// main function
void main(void)
{
    unsigned short check;
    
    ADCON1 = 0x0F;

    INTCON = 0b11100000;        /* GIE/GIEH  = 1 - Habilita interrup��o global
                                 * PEIE/GIEL = 1 - Habilita interrup��o de Perif�ricos
                                 * TMR0IE = 1 - Habilita interrup��o pelo TIMER0
                                 * INT0IE = 0 - N�o utilizado
                                 * RBIE = 0 - N�o utilizado
                                 * TMR0IF = 0 - Flag de overflow p/ o TIMER0
                                 * INT0IF = 0 - N�o utilizado
                                 * RBIE = 0 - N�o utilizado
                                 */

    T0CON = 0b11000111;         /* TMR0ON = 1 - Habilita TIMER0
                                 * T08BIT = 1 - Modo de opera��o em 8 bits
                                 * T0CS = 0 - Incremento pelo ciclo de m�quina
                                 * T0SE = 0 - N�o se aplica
                                 * PSA = 0 - Prescaler habilitado
                                 * PS2, PS1, PS0 = 1 - Prescaler de 1:256
                                 */

    TMR0L = 61;                  //Valor inicial para o reg. TMR0

    // ** Interrup��o pela recep��o de dados na serial **
    RCIF_bit=0;        //Limpa o Flag de Interrup��o por rece��o na serial
    RCIE_bit=1;        //Habilita interrup��o por recep��o na serial
    
    T1CON = 0x10;                    // Set Timer1 clock source to internal with 1:2 prescaler (Timer1 clock = 1 MHz)
    TMR1H = 0;                       // Reset Timer1
    TMR1L = 0;

    TRISA.F3 = 0;   //Direciona o pino 3 da porta A como sa�da
    TRISA.F5 = 0;   //Direciona o pino 5 da porta A como sa�da
    RA3_bit = 0;
    Ra5_bit = 0;
    //TRISD.F0 = 0;   //Direciona o pino 0 da porta D como sa�da

    UART1_Init(9600);          //Inicia USART
    
    delay_ms(300);

  while(1)
  {
//        bufUSART[0] = 'T';
//        bufUSART[1] = 'M';
//        bufUSART[2] = 'P';
//        bufUSART[3] = ':';
//
//        bufUSART[4] = ((temp / 100) % 10) + 0x30;
//        bufUSART[5] = ((temp / 10) % 10) + 0x30;
//        bufUSART[6] = (temp % 10) + 0x30;
//
//        bufUSART[7] = ':';
//
//        bufUSART[8] = 'U';
//        bufUSART[9] = 'M';
//        bufUSART[10] = 'D';
//        bufUSART[11] = ':';
//
//        bufUSART[12] = ((rh / 100) % 10) + 0x30;
//        bufUSART[13] = ((rh / 10) % 10) + 0x30;
//        bufUSART[14] = (rh % 10) + 0x30;
//
//        bufUSART[15] = ':';
//
//        bufUSART[16] = rl1 + 0x30;
//        bufUSART[17] = rl2 + 0x30;
        
        UART1_Write('T');
       UART1_Write('M');
        UART1_Write('P');
       UART1_Write(':');

        UART1_Write(((temp / 100) % 10) + 0x30);
        UART1_Write(((temp / 10) % 10) + 0x30);
        UART1_Write((temp % 10) + 0x30);

        UART1_Write(':');

        UART1_Write('U');
       UART1_Write('M');
        UART1_Write('D');
        UART1_Write(':');

        UART1_Write(((rh / 100) % 10) + 0x30);
        UART1_Write(((rh / 10) % 10) + 0x30);
        UART1_Write((rh % 10) + 0x30);

        UART1_Write(':');

        UART1_Write(rl1 + 0x30);
        UART1_Write(rl2 + 0x30);
        UART1_Write('\n');
        //bufUSART[18] = '\n';
        //UART1_Write_Text(bufUSART);
        
        delay_ms(300);    //Gera atraso de 300ms

        if (tmp)            //Caso tmp seja 1 (2 segundos)
        {
            //RD0_bit = ~RD0_bit;
        
            start_signal();             //Envia o sinal de inicializa��o p/ sensor

            check = check_response();   //Verifica resposta do sensor
            
            UART1_Write(check + 0x30);

            if (!check)                 //Caso falhe a reposta
            {
                //Escreve a informa��o na serial
                UART1_Write_Text("Sem resposta do Sensor\r\n");
            }
            else                        //Caso n�o haja problemas na reposta
            {
                /*Faz a leitura dos primeiros e segundos bytes da unmidade e
                temperatura e do checksum */
                RH_byte1 = read_byte();
                RH_byte2 = read_byte();
                T_byte1 = read_byte();
                T_byte2 = read_byte();
                CheckSum = read_byte();

                //Armazena em rh o resultado da leitura de umidade
                rh   = RH_byte2 | (RH_byte1<<8);

                //Armazena em temp o resultado da leitura de temperatura
                temp = T_byte2  | (T_byte1<<8);
                
//                bufUSART[4] = ((temp / 100) % 10) + 0x30;
//                bufUSART[5] = ((temp / 10) % 10) + 0x30;
//                bufUSART[6] = (temp % 10) + 0x30;
//
//                bufUSART[12] = ((rh / 100) % 10) + 0x30;
//                bufUSART[13] = ((rh / 10) % 10) + 0x30;
//                bufUSART[14] = (rh % 10) + 0x30;

                /*
                 * Obs.: Neste c�digo optou-se por n�o verificar a possibilidade
                 * de temperatura negativa
                */

                // Verifica se existe falha no checksum
                if (CheckSum != ((RH_byte1 + RH_byte2 + T_byte1 + T_byte2) & 0xFF))
                {
                    //caso haja, informa na serial
                    UART1_Write_Text("CheckSum Error\r\n");
                }
            }
        tmp = 0;    //retorna a vari�vel tmp para 0
        }
   }
}
// End of code.